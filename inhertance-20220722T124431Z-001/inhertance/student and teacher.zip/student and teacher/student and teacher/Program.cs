using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student_and_teacher
{

    class Person
    {
        protected string name;
        protected int age;
    }
    class Student : Person
    {
        protected float percentage;
        public void getdata()
        {
            name = "sankar";
            age = 29;
            percentage = 75;
        }
        public void display()
        {
            Console.WriteLine("\n\n\t----student information---");
            
            Console.WriteLine("\n\tstudent name :" + name);
            Console.WriteLine("\n\tstudent age :" + age);
            Console.WriteLine("\n\tstudent percentage :" + percentage);
            Console.WriteLine("\n\t-----------------------");
        }

        

    }
    class teacher : Person
    {
        protected int salary;
        public void getdata()
        {
            name = "sagar nahak";
            age = 45;
            salary = 65000;
        }
        public void display()
        {
            Console.WriteLine("\n\n\t----teacher information---");
            Console.WriteLine("\n\tteacher name :" + name);
            Console.WriteLine("\n\tteacher age :" + age);
            Console.WriteLine("\n\tteacher salary " + salary);
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();
            s.getdata();
            s.display();
            teacher t = new teacher();
            t.getdata();
            t.display();

            Console.Read();
        }
    }
}
