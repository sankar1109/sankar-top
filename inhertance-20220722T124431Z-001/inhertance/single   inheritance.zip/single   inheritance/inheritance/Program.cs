using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritance
{
    class Action

    {
        public int roll_num;
        public string name;
    }

    class Student : Action

    {
        public void getdata()
        {
            roll_num = 15;
            name = "sankar";
        }
        public void Display()
        {
            Console.WriteLine(roll_num);
            Console.WriteLine( name);
        }
        
}
   

    

    class Program
    {
        static void Main(string[] args)
        {


            Student s = new Student();
           
            s.getdata();
            s.Display();
            Console.ReadKey();
            
        }
    }
}
