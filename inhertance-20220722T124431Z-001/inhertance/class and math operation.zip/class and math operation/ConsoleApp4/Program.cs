using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class math
    {
        public int a, b, c;
        public int d, e, f, i;
        
            public void getdata()
        {
            Console.WriteLine("please enter the values of a :");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("please enter the values of b :");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("please enter the values of c :");
            c = Convert.ToInt32(Console.ReadLine());

        }
        public void operation()
        {
            e = a + b;
            f = a-c;
            d = a * b;
            i = a / b;
        }
        public void display()
        {
            Console.WriteLine("\n\taddition of two number is :" + e);
            Console.WriteLine("\n\tsubtraction  of two number is :" + f);
            Console.WriteLine("\n\tmultiplication of two number is :" + d);
            Console.WriteLine("\n\tdivision of two number is :" + i);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            math a = new math();
            a.getdata();
            a.operation();
            a.display();
            Console.Read();
        }
    }
}
