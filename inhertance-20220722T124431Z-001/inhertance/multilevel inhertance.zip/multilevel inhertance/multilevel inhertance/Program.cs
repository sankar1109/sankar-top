using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace multilevel_inhertance
{
    class student
    {
        protected string name;
        protected int roll;
    }
    class test : student
    {
        protected int subject1;
        protected int subject2;
    }
    class result : test
    {
        public int totalmarks;
        public int percentage;
        public void getdata()
        {
            name = "sankar";
            roll = 23505;
            subject1 = 65;
            subject2 = 75;
            totalmarks = subject1 + subject2;
            
            
          
        }
        public void display()
        {
            Console.WriteLine("\n\tstudent name is : " + name);
            Console.WriteLine("\n\tstudent roll number  is : " + roll);
            Console.WriteLine("\n\tstudents subject1 marks is: " + subject1);
            Console.WriteLine("\n\tstudents subject2 marks is: " + subject2);
            Console.WriteLine("\n\tstudent obtain total marks : " + totalmarks);
           
        }

    }



    class Program
    {
        static void Main(string[] args)
        {
            result t = new result();
            t.getdata();
            t.display();
            Console.ReadKey();
        }
    }
}
