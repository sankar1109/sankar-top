using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace single_inheritance_batman
{
    class Crickter
    {
        protected string name;
        protected int age;
        protected int run;
        protected Double avg;
        protected string per;

    }
    class batsman : Crickter
    {
        public void getdata()
        { 
                name = " sachin tendulkar";
                age = 21;
                run = 13251;
                avg = 56.26;
                per = "execelent";
        }
        public void display()
        {
            Console.WriteLine("\n\tbatsman name : " + name);
            Console.WriteLine("\n\tbatsman age :" + age);
            Console.WriteLine("\n\tbatsman run :" + run);
            Console.WriteLine("\n\tbatsman avg:" + avg);
            Console.WriteLine("\n\tbatsman per :" + per);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            batsman c = new batsman();
            c.getdata();
            c.display();

            Console.Read();             
        }
    }
}
