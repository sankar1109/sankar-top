using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace class_and_function
{

    class student
    {
        public int roll_num;
        public string stu_name;

        public void getdata()
        {
        roll_num = 15;
            stu_name = "sankar nahak";
        }
        public void display()
        {
            Console.WriteLine("roll_num :" + roll_num);
            Console.WriteLine("student name : " + stu_name);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            student a = new student();
            a.getdata();

            a.display();
            Console.ReadKey();

            
         
        }
    }
}
