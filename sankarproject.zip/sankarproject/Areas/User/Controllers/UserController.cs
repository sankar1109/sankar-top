﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using sankarproject.EDM;
using System.Diagnostics;

namespace sankarproject.Areas.User.Controllers
{
    public class UserController : Controller
    {
        // GET: User/User
        projectEntities p = new projectEntities();
        public ActionResult Homepage()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(FormCollection fc)
        {
            string email = fc["email"];
            string pass = fc["password"];
            var obj = p.User_Info.Where(x => x.Email == email && x.password == pass).FirstOrDefault();
        
            if (obj != null)
            {
                Session["UserId"] = obj.id;
                Session["UserName"] = obj.Frist_Name;
                
                return RedirectToAction("Homepage");
            }
            ViewBag.loginerror = "Invalid Email Or Password";
            return View();

        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("HomePage");
        }
        public ActionResult  productlist()
        {
            var data = p.product1.ToList();
            return View(data);
        }
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(FormCollection fc)
        {
            User_Info obj = new User_Info();

            obj.id = Convert.ToInt32(fc["txtid"]);
            obj.Frist_Name = fc["txtfn"];
            obj.Last_Name = fc["txtln"];
            obj.Email= fc["email"];
            obj.Address = fc["txtA"];
            obj.password = fc["password"];
            obj.Number = fc["txtn"];
            obj.Shiping_Id = Convert.ToInt32(fc["txts"]);
            obj.State_Id = Convert.ToInt32(fc["txtsi"]);
            p.User_Info.Add(obj);
            p.SaveChanges();
            return RedirectToAction("HomePage");
        }
        public ActionResult Single(int id)
        {
            return View(p.product1.Find(id));
        }
       

        public ActionResult Cart()
        {
            
          int userid = Convert.ToInt32(Session["UserId"].ToString());
            var data = p.carts.ToList();
            
            return View(p.carts.Where(c=>c.id==userid).ToList());
        }

        public string AddToCart(int id  )
        {
            cart obj = new cart;
            int userid = Convert.ToInt32(Session["UserId"].ToString());

            var cartobj = p.carts.Where(c => c.id== id && c.id == userid).FirstOrDefault();
            if (cartobj == null)
            {
                cart obj = new cart();
                obj.product_id = id;
                obj.qty = 1;
                obj.id = userid;

                p.carts.Add(obj);
                p.SaveChanges();
            }
            else
            {
                cartobj.qty += 1;
                p.Entry(cartobj).State = System.Data.Entity.EntityState.Modified;
                p.SaveChanges();
            }

            return "Product added to cart.";
        }
        [HttpPost]
        public string UpdateCartQty(int cart_id, int qty)
        {
            var obj = p.carts.Find(cart_id);
            obj.qty = qty;

            p.Entry(obj).State = System.Data.Entity.EntityState.Modified;
            p.SaveChanges();
            return "Cart Qty updated.";
        }










    }
}