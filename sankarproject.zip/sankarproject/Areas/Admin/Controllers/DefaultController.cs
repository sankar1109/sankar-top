﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using sankarproject.EDM;

namespace sankarproject.Areas.Admin.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Admin/Default
        projectEntities p = new projectEntities();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]

        public ActionResult Login(FormCollection fc)
        {
            string email = fc["email"];
            string pass = fc["password"];
            var obj = p.Admins.Where(x => x.Email_id == email && x.password == pass).FirstOrDefault();

            if (obj != null)
            {
                Session["Adminid"] = obj.Admin_id;
                Session["AdminName"] = obj.Frist_Name;

                return RedirectToAction("Dashboard");
            }
            ViewBag.loginerror = "Invalid Email Or Password";
            return View();

        }
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Login");
        }




    }
}